class GameScraper():
    def __init__(self):
        return super().__init__()

    def __str__(self):
        return ''

    def search(self, name: str):
        return None

    def getInfo(self, id: str):
        info = {'id': id, 'title': None, 'altTitle': None, 'platform': None, 'year': None, 'developer': None, 'publisher': None, 'genres': None, 'overview': None, 'rating': None, 'thumbs': None, 'fanarts': None}
        return None
